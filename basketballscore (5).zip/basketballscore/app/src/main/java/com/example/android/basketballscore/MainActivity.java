package com.example.android.basketballscore;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int score1 = 0;

    public void plusThreeLeft(View v) {
        score1 += 3;
        TextView t = (TextView) findViewById(R.id.scoreone);
        t.setText("" + score1);
    }

    public void plusTwoLeft(View v) {
        score1 += 2;
        TextView t = (TextView) findViewById(R.id.scoreone);
        t.setText("" + score1);
    }

    public void plusOneLeft(View v) {
        score1 += 1;
        TextView t = (TextView) findViewById(R.id.scoreone);
        t.setText("" + score1);
    }

    int score2 = 0;

    public void plusThreeRight(View v) {
        score2 += 3;
        TextView t2 = (TextView) findViewById(R.id.scoretwo);
        t2.setText("" + score2);
    }

    public void plusTwoRight(View v) {
        score2 += 2;
        TextView t2 = (TextView) findViewById(R.id.scoretwo);
        t2.setText("" + score2);
    }

    public void plusOneRight(View v) {
        score2 += 1;
        TextView t2 = (TextView) findViewById(R.id.scoretwo);
        t2.setText("" + score2);
    }

    public void reset(View v) {
        score1 = 0;
        TextView t = (TextView) findViewById(R.id.scoreone);
        t.setText("" + score1);
        score2 = 0;
        TextView t2 = (TextView) findViewById(R.id.scoretwo);
        t2.setText("" + score2);

    }

    public void minusOneLeft(View v) {
        score1 -= 1;
        TextView t = (TextView) findViewById(R.id.scoreone);
        t.setText("" + score1);

    }

    public void minusOneRight(View v) {
        score2 -= 1;
        TextView t2 = (TextView) findViewById(R.id.scoretwo);
        t2.setText("" + score2);

    }
}
